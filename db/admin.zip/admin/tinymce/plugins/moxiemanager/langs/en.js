tinymce.addI18n('en',{
	moxiemanager_insert:"Insert file"
});
