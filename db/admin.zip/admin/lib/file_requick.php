<?php
	if(!defined('_kiemtraweb') || _kiemtraweb!=$check_website) die('Eror');
	
	$com = (isset($_REQUEST['com'])) ? addslashes($_REQUEST['com']) : "";
	$act = (isset($_REQUEST['act'])) ? addslashes($_REQUEST['act']) : "";
	$d = new database($config['database']);
	$trangchu = 0;

	switch($com){
		case 'about-us':
			$source = "about/gioithieu";
			$template = "about/gioithieu";
			break;
//		case 'hinh-anh':
//			$source = "hinhanh/hinhanh";
//			$template = "hinhanh/hinhanh";
//			break;
		case 'product':
			$source = "sanpham/sanpham";
			$template = "sanpham/sanpham";
			break;

		case 'project':
			$source = "about/project";
			$template = "about/project";
			break;
//		case 'tin-tuc':
//			$source = "tintuc/news";
//			$template = "tintuc/news";
//			break;
		case 'contact':
			$source = "contact/contact";
			$template = "contact/contact";
			break;

		case 'tim-kiem':
			$source = "sanpham/timkiem";
			$template = "sanpham/timkiem";
			break;

		default:
			$index = 1;
			$source = "index";
			$template = "index";
			break;
	}
	//CODE SÀI CHUNG CHO WEBSITE

	$d->reset();
	$sql = "select * from #_photo where hienthi=1 and com='logo'";
	$d->query($sql);
	$logo = $d->fetch_array();

	$d->reset();
	$sql = "select * from #_photo where hienthi=1 and com='banner'";
	$d->query($sql);
	$banner = $d->fetch_array();

	//Thông tin Website
	$sql = "select * from #_company where com='company' limit 0,1";
	$d->query($sql);
	$company = $d->fetch_array();			
	
	$title_bar = $company[$ten].' | '.$company['slogan'];
	$description = $company['description'];
	$keywords = $company['keywords'];

	$template.="_tpl.php";

//	$sql = "select * from #_about where com='vchat' order by id desc limit 0,1";
//	$d->query($sql);
//	$vchat = $d->fetch_array();
//	$vchat = $vchat['noidung_vi'];

//	$d->reset();
//	$sql = "select * from #_photo where hienthi=1 and com='lkweb' order by stt desc, id desc";
//	$d->query($sql);
//	$social = $d->result_array();

	if($source!="") include _source.$source.".php";

?>