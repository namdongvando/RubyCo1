<?php if(!defined('_lib')) die("Error");

$config_url=$_SERVER["SERVER_NAME"];

$config_host="112.213.88.184";
$config_email="info@qmts.com.vn";
$config_pass="IaNp9G1i";

$login_name = 'it-me';
$check_website = 'Developer & Designer';

$config['database']['servername'] = 'localhost';
$config['database']['username'] = 'qmtscomv_ll';
$config['database']['password'] = 'Vietit2017';
$config['database']['database'] = 'qmtscomv_ll';
$config['database']['refix'] = 'table_';

?>