<?php if(!@defined('_lib')) die("Error");		
	
	@define ( _updating , "Đang cập nhật thông tin" );
		
	
	@define ( _upload_download, '../upload/download/' );
	@define ( _upload_download_l , 'upload/download/' );
	
	@define ( _upload_tin3cap, '../upload/tin3cap/' );
	@define ( _upload_tin3cap_l , 'upload/tin3cap/' );
	
	@define ( _upload_images, '../upload/images/' );
	@define ( _upload_images_l , 'upload/images/' );
	
	@define ( _upload_slide , '../upload/slide/' );
	@define ( _upload_slide_l , 'upload/slide/' );
	
	@define ( _upload_tintuc , '../upload/news/' );
	@define ( _upload_tintuc_l , 'upload/news/' );
	
	@define ( _upload_tinnho , '../upload/tinnho/' );
	@define ( _upload_tinnho_l , 'upload/tinnho/' );
	
	
	@define ( _upload_hinhanh , '../upload/hinhanh/' );
	@define ( _upload_hinhanh_l , 'upload/hinhanh/' );
		
	
	@define ( _upload_sanpham , '../upload/sanpham/' );
	@define ( _upload_sanpham_l , 'upload/sanpham/' );

	
?>