<?php if (!defined('_kiemtraweb') || _kiemtraweb != $check_website) daysangtranglogin(); ?>
<!-- Breadcrumbs Start -->
<script language="JavaScript">
    $(document).ready(function(){
        var i = 2;
        function inputIncrement(){
            var x = $("#inputIncrement");
            x.val();
            if(!$.isNumeric(x.val())){
                alert("Vui lòng chỉ nhập số");
                return false;
            }

            var innerHtml = $("#innerHtml");
            for(;i<=parseInt(x.val());i++){
                var str_Fill = '<div class="col-md-12" style="margin-top:25px;"></div>'+
                '<div class="col-md-2">'+
                    '<label>Hình ảnh '+i+'</label>'+
                    '</div><div class="col-md-10">'+
                    '<input type="file" name="file'+i+'"/>'+
                '</div>'+
                '<div class="col-md-2"><label>Tiêu đề ảnh '+i+'</label></div>'+
                '<div class="col-md-10"><input type="text" name="ten_vi'+i+'" placeholder="Tiêu đề ảnh"/></div>';
                innerHtml.html(innerHtml.html()+str_Fill);
            }
            var inputHidden = '<input type="hidden" value="'+ x.val()+'" name="dataCount">';
            innerHtml.html(innerHtml.html()+inputHidden);
            x.val('');
            return false;
        }
        $("#btn-ok").click(function(){
            inputIncrement();
        });

        var keyPress = $("#inputIncrement");
        keyPress.keypress(function(event){
            if(event.keyCode == 13){
                inputIncrement();
            }
        });
    });
</script>

<div class="row breadcrumbs">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <ul class="breadcrumbs">
            <li><a href="index.php"><i class="fa fa-home"></i></a></li>
            <li><a href="index.php?com=photo&act=man_lkweb"><?php echo $t_cat?></a></li>
        </ul>
    </div>
</div>
<!-- Breadcrumbs End -->
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

    <!-- Inline Form Start -->
    <div class="boxed no-padding col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="inner">
            <!-- Title Bar Start -->
            <div class="title-bar">
                <h4><?php echo $t_cat?></h4>
            </div>
            <!-- Title Bar End -->

            <form method="post" name="frm" action="index.php?com=images&act=save_index<?= $chuoi_noi_curpage ?>"
                  enctype="multipart/form-data" class="basic-form inline-form">
                <div class="container" style="padding: 0 10px;">
                    <div class="col-md-2"><label>Kiểu ảnh</label></div>
                    <div class="col-md-10">
                        <span class="description">Type: .jpeg/.jpg|.gif|.png</span>
                        <br/><br/>
                    </div>
                </div>
                <?php if ($_REQUEST['act'] == 'add_index') { ?>
                    <div class="col-md-2"><label>Nhập số lượng hình ảnh</label></div>
                    <div class="col-md-10">
                        <div class="col-md-4" style="padding: 0;">
                        <div class="input-group">
                            <input id="inputIncrement" type="text" class="form-control" name="inputIncrement"
                                   placeholder="Nhập số lượng hình ảnh" maxlength="2" width="25">
                            <span class="input-group-addon" style="padding:0;">
                                <input id="btn-ok" type="button" class="input-group-addon" style="margin: 0;border: 0" value="Ok"/>
                            </span>
                        </div>
                        </div>
                    </div>
                    <div class="container-fluid">&nbsp;</div>
                <?php } ?>


                <?php if ($_REQUEST['act'] == 'edit_index') { ?>
                    <div class="col-md-2"><label>Hình hiện tại</label></div>
                    <div class="col-md-10"><img src="<?= _upload_hinhanh . $item['photo'] ?>" style="background: #eee"
                                                width="50%" alt="NO PHOTO"/><br/><br/></div>
                <?php } ?>

                <div class="col-md-2"><label>Hình ảnh</label></div>
                <div class="col-md-10">
                    <input type="file" name="file"/>
                </div>

                <div class="col-md-2"><label>Tiêu đề ảnh</label></div>
                <div class="col-md-10"><input type="text" name="ten_vi" value="<?= $item['ten'] ?>" placeholder="Tiêu đề ảnh"/></div>
                <!--<div class="col-md-2"><label>Mô Tả</label></div>
                <div class="col-md-10"><input type="text" name="mota" value="<? /*=$item['mota']*/ ?>" placeholder="Mô Tả" /></div>-->
                <!--<div class="col-md-2"><label>Link</label></div>
                <div class="col-md-10"><input type="text" name="link" value="<? /*=$item['link']*/ ?>" placeholder="Ví dụ: http://zing.vn/" />
                	<span class="description">Ví dụ: http://zing.vn/</span>
                    <br /><br />
                </div>-->

                <div id="innerHtml"></div>

                <!--<div class="col-md-2"><label>Số thứ tự</label></div>
                <div class="col-md-10"><input type="text" name="stt" id="stt" value="<?/*= isset($item['stt']) ? $item['stt'] : 1 */?>" placeholder="Số thứ tự"/></div>-->
                <div class="col-md-2"></div>
                <div class="col-md-10"><input type="checkbox" name="hienthi"
                                              class="icheck-blue" <?= (!isset($item['hienthi']) || $item['hienthi'] == 1) ? 'checked="checked"' : '' ?> />
                    <span class="hienthi_text">Hiển thị</span></div>

                <input type="hidden" name="id" id="id" value="<?= @$item['id'] ?>"/>

                <div class="col-md-10 col-md-offset-2">
                    <button type="button" onclick="javascript:document.frm.submit()" class="btn btn-success"><i
                            class="fa fa-check"></i> Lưu
                    </button>
                    <button type="button"
                            onclick="javascript:window.location='index.php?com=images&act=index<?= !empty($case) ? "&case=$case" : "" ?>'"
                            class="btn btn-info"><i class="fa fa-share"></i> Thoát
                    </button>
                </div>

                <div class="clearfix"></div>

            </form>

        </div>
    </div>
    <!-- Inline Form End -->
</div>