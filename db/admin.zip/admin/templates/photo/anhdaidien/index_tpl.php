<?php if (!defined('_kiemtraweb') || _kiemtraweb != $check_website) daysangtranglogin(); ?>

<!-- Breadcrumbs Start -->
<div class="row breadcrumbs">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <ul class="breadcrumbs">
            <li><a href="index.php"><i class="fa fa-home"></i></a></li>
            <li><a href="index.php?com=photo&act=capnhap_background">Ảnh đại diện dịch vụ chăm sóc</a></li>
        </ul>
    </div>
</div>
<!-- Breadcrumbs End -->

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <!--<div class="inner" style="margin-bottom:10px;">
        <div class="message-box info">
          <i class="fa fa-exclamation-circle"></i>
          <p>Lưu ý: Chỉ nên có tối đa 4-5 bản đồ, tên bản đồ không nên đặt dài quá, nên đặt số thứ tự chính xác để dễ quản lý!</p>
        </div>
    </div>-->


    <!-- Inline Form Start -->
    <div class="boxed no-padding col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="inner">

            <!-- Title Bar Start -->
            <div class="title-bar">
                <h4>Ảnh đại diện dịch vụ chăm sóc</h4>
            </div>
            <!-- Title Bar End -->

            <form method="post" name="frm"
                  action="index.php?com=photo&act=save_anhdaidien<?php echo $chuoi_noi_curpage; ?>"
                  enctype="multipart/form-data" class="basic-form inline-form">
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-2"><label>Hình hiện tại</label></div>
                        <div class="col-md-10"><img src="<?= _upload_hinhanh . $item['photo'] ?>" width="300"
                                                    alt="NO PHOTO"/><br/><br/></div>
                        <div class="col-md-2"><label>Hình ảnh</label></div>
                        <div class="col-md-10">
                            <input type="file" name="file"/>
                            <span class="description">Type: .jpg|.gif|.png|.jpeg &nbsp;&nbsp;;&nbsp;&nbsp; Ảnh chuẩn: 606x473 px</span>
                            <br/><br/>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <input type="hidden" id="<?php echo $item['id'];?>"
                           <div class="col-md-2"></div>
                    <div class="col-md-10 col-md-offset-2">
                        <button type="button" onclick="javascript:document.frm.submit()" class="btn btn-success">
                            <i class="fa fa-check"></i> Lưu
                        </button>
                        <button type="button"
                                onclick="javascript:window.location='index.php?com=tinnho&act=index<?php echo $chuoi_noi_curpage?>'"
                                class="btn btn-info"><i class="fa fa-share"></i> Thoát
                        </button>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </form>

        </div>
    </div>
    <!-- Inline Form End -->
</div>