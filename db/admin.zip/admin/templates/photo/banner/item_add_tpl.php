<?php if (!defined('_kiemtraweb') || _kiemtraweb != $check_website) daysangtranglogin();
function radioSelect($c,$value){;
    $select = "";
    if($c === $value)
        $select = "checked";
    return $select;
}

function getName($c)
{
    $name = "";
    switch ($c) {
        case "san-pham":
            $name = "Sản phẩm";
            break;
        case "thong-tin":
            $name = "Thông tin";
            break;
        case "bai-viet":
            $name = "Bài viết";
            break;
        case "ve-moah":
            $name = "Về MOAH";
            break;
        case "lien-he":
            $name = "Liên hệ";
            break;
        case "tim-kiem":
            $name = "Liên hệ";
            break;
    }
    return $name;
}

?>
<!-- Breadcrumbs Start -->
<style>
    input[type="radio"] {
        width: auto!important;
    }

    label.radio-inline {
        float: left;
        margin: auto;
    }
</style>
<div class="row breadcrumbs">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <ul class="breadcrumbs">
            <li><a href="index.php"><i class="fa fa-home"></i></a></li>
            <li><a href="index.php?com=photo&act=index">Banner <?php echo getName($item['com'])?></a></li>
        </ul>
    </div>
</div>
<!-- Breadcrumbs End -->

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <!-- Inline Form Start -->
    <div class="boxed no-padding col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="inner">

            <!-- Title Bar Start -->
            <div class="title-bar">
                <h4>Banner <?php echo getName($item['com'])?></h4>
            </div>
            <!-- Title Bar End -->

            <form method="post" name="frm" action="index.php?com=photo&act=save_index<?= $chuoi_noi_curpage ?>"
                  enctype="multipart/form-data" class="basic-form inline-form">
                <?php if ($_REQUEST['act'] == 'edit_index') { ?>
                    <div class="col-md-2"><label>Hình hiện tại</label></div>
                    <div class="col-md-10"><img src="<?= _upload_hinhanh . $item['photo'] ?>" width="494px" height="" alt="NO PHOTO"/><br/><br/></div>
                <?php } ?>
                <div class="col-md-2"><label>Hình ảnh</label></div>
                <div class="col-md-10">
                    <input type="file" name="file"/>
                    <span class="description">Type: .jpg|.gif|.png|.jpeg &nbsp;&nbsp;;&nbsp;&nbsp; Kích thước ảnh chuẩn: width: 1366px-height 569px</span>
                    <br/><br/>
                </div>

                <div class="hidden">
                <div class="col-md-2"><label>Chọn danh mục</label></div>
                <div class="col-md-10">
                    <div class="container">
                    <label class="radio-inline">
                        <input type="radio" name="case" value="san-pham" <?php echo radioSelect($item['com'],"san-pham");?>>Sản phẩm
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="case" value="thong-tin" <?php echo radioSelect($item['com'],"thong-tin");?>>Thông tin
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="case" value="bai-viet" <?php echo radioSelect($item['com'],"bai-viet");?>>Bài viết
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="case" value="ve-moah" <?php echo radioSelect($item['com'],"ve-moah");?>>Về MOAH
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="case" value="lien-he" <?php echo radioSelect($item['com'],"lien-he");?>>Liên hệ
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="case" value="tim-kiem" <?php echo radioSelect($item['com'],"tim-kiem");?>>Tìm kiếm
                    </label>
                    </div>
                </div>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-10"><input type="checkbox" name="hienthi"
                                              class="icheck-blue" <?= (!isset($item['hienthi']) || $item['hienthi'] == 1) ? 'checked="checked"' : '' ?> />
                    <span class="hienthi_text">Hiển thị</span></div>

                <input type="hidden" name="id" id="id" value="<?= @$item['id'] ?>"/>

                <div class="col-md-10 col-md-offset-2">
                    <button type="button" onclick="javascript:document.frm.submit()" class="btn btn-success"><i
                            class="fa fa-check"></i> Lưu
                    </button>
                    <button type="button"
                            onclick="javascript:window.location='index.php?com=photo&act=index<?= $chuoi_noi_curpage ?>'"
                            class="btn btn-info"><i class="fa fa-share"></i> Thoát
                    </button>
                </div>

                <div class="clearfix"></div>

            </form>

        </div>
    </div>
    <!-- Inline Form End -->
</div>