<?php if(!defined('_kiemtraweb') || _kiemtraweb!=$check_website) daysangtranglogin(); ?>

<!-- Breadcrumbs Start -->
  <div class="row breadcrumbs">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <ul class="breadcrumbs">
        <li><a href="index.php"><i class="fa fa-home"></i></a></li>
        <li><a href="index.php?com=photo&act=capnhap_bg">Cập nhập Background</a></li>
      </ul>
    </div>
  </div>
  <!-- Breadcrumbs End -->
        
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    	<!--<div class="inner" style="margin-bottom:10px;">
            <div class="message-box info">
              <i class="fa fa-exclamation-circle"></i>
              <p>Lưu ý: Thông thường trên SmartPhone không hỗ trợ FLASH nên cần nhập BANNER Trên SmartPhone là 1 file hình ảnh!</p>
            </div>
        </div>-->
    
    
		<!-- Inline Form Start -->
          <div class="boxed no-padding col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="inner">

              <!-- Title Bar Start -->
              <div class="title-bar">
                <h4>Cập nhập Background</h4>
              </div>
              <!-- Title Bar End -->
			              
              <form method="post" name="frm" action="index.php?com=photo&act=save_bg" enctype="multipart/form-data" class="basic-form inline-form">
                <div class="col-md-12">
                  <div class="col-md-3"><label>Current Background:</label></div>
                  <div class="col-md-9">
                      <?php if($item['photo']!=NULL){ ?>
                      <object style="max-width:100%;" width="550" height="96"  codebase="http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
                        <param NAME="_cx" VALUE="13414">
                        <param NAME="_cy" VALUE="6641">
                        <param NAME="FlashVars" VALUE>
                        <param NAME="Movie" VALUE="<?=_upload_hinhanh.$item['photo']?>">
                        <param NAME="Src" VALUE="<?=_upload_hinhanh.$item['photo']?>">
                        <param NAME="Quality" VALUE="High">
                        <param NAME="AllowScriptAccess" VALUE>
                        <param NAME="DeviceFont" VALUE="0">
                        <param NAME="EmbedMovie" VALUE="0">
                        <param NAME="SWRemote" VALUE>
                        <param NAME="MovieData" VALUE>
                        <param NAME="SeamlessTabbing" VALUE="1">
                        <param NAME="Profile" VALUE="0">
                        <param NAME="ProfileAddress" VALUE>
                        <param NAME="ProfilePort" VALUE="0">
                        <param NAME="AllowNetworking" VALUE="all">
                        <param NAME="AllowFullScreen" VALUE="false">
                        <param name="scale" value="ExactFit">
                        <embed style="max-width:100%;" src="<?=_upload_hinhanh.$item['photo']?>" quality="High" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" width="1000" height="auto" scale="ExactFit"></embed>
                      </object>
                      <?php }else{ echo "Background not exist"; }?><br /><br />
                  </div>
                  <div class="col-md-12">
                    <div class="col-md-3"><label>Choose header background</label></div>
                    <div class="col-md-9">
                        <input type="file" name="file" />
                        <span class="description">Width:1366px&nbsp;<!---&nbsp;Height:137px-->&nbsp;Type:&nbsp;<!--.swf | -->.jpeg | .gif | .png | .gif</span>
                        <br /><br />
                    </div>
                  </div>
                </div>
                <div class="col-md-12"></div>
                <div class="col-md-3"><label>Current bottom background:</label></div>
                <div class="col-md-9">
                	<?php if($item['thumb']!=NULL){ ?>            
                    <img src="<?=_upload_hinhanh.$item['thumb']?>" width="1000" height="auto" border="0" style="max-width:100%;" />
                    <?php }else{ echo "Background not exist"; }?><br /><br />
                </div>
                <div class="col-md-12">
                  <div class="col-md-3"><label>Choose bottom background</label></div>
                  <div class="col-md-9">
                      <input type="file" name="file1" />
                      <span class="description">Width:1366px&nbsp;<!---&nbsp;Height:137px-->&nbsp;Type:&nbsp; .jpeg | .gif | .png | .gif</span>
                      <br /><br />
                  </div>
                </div>

                <div class="col-md-10 col-md-offset-2">                  
                  <button type="button" onclick="javascript:document.frm.submit()" class="btn btn-success"><i class="fa fa-check"></i> Lưu</button>
                  <button type="button" onclick="javascript:window.location='index.php?com=photo&act=capnhap_banner'" class="btn btn-info"><i class="fa fa-share"></i> Thoát</button>
                </div>

                <div class="clearfix"></div>

              </form>

            </div>
          </div>
          <!-- Inline Form End -->
	</div>