<?php if(!defined('_kiemtraweb') || _kiemtraweb!=$check_website) daysangtranglogin(); ?>

<!-- Breadcrumbs Start -->
  <div class="row breadcrumbs">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <ul class="breadcrumbs">
        <li><a href="index.php"><i class="fa fa-home"></i></a></li>
        <li><a href="index.php?com=photo&act=partner">Partner</a></li>
      </ul>
    </div>
  </div>
  <!-- Breadcrumbs End -->
        
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    	<!--<div class="inner" style="margin-bottom:10px;">  			
            <div class="message-box info">
              <i class="fa fa-exclamation-circle"></i>
              <p>Lưu ý: Chỉ nên có tối đa 4-5 bản đồ, tên bản đồ không nên đặt dài quá!</p>
            </div>
        </div>-->
    
    
		<!-- Inline Form Start -->
          <div class="boxed no-padding col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="inner">

              <!-- Title Bar Start -->
              <div class="title-bar">
                <h4>Partner</h4>
              </div>
              <!-- Title Bar End -->

              <form method="post" name="frm" action="index.php?com=photo&act=save_partner<?=$chuoi_noi_curpage?>" enctype="multipart/form-data" class="basic-form inline-form">
              	<?php if ($_REQUEST['act']=='edit_lkweb'){?>
                <div class="col-md-2"><label>Current Image</label></div>
                <div class="col-md-10" ><img src="<?=_upload_hinhanh.$item['photo']?>" style="background: #eee" width="auto" alt="NO PHOTO" /><br /><br /></div>
                <?php }?>
                <div class="col-md-2"><label>Change Image</label></div>
                <div class="col-md-10">
                	<input type="file" name="file" /> 
                    <span class="description">Type: .jpg|.gif|.png|.jpeg &nbsp;&nbsp;;&nbsp;&nbsp; Original: auto x 60 (theo px)</span>
                    <br /><br />
                </div>
                            
                <div class="col-md-2"><label>Partner Name</label></div>
                <div class="col-md-10"><input type="text" name="ten_vi" value="<?=$item['ten_vi']?>" placeholder="Tên" /></div>
                <!--<div class="col-md-2"><label>Mô Tả</label></div>
                <div class="col-md-10"><input type="text" name="mota" value="<?/*=$item['mota']*/?>" placeholder="Mô Tả" /></div>-->
                <div class="col-md-2"><label>Link</label></div>
                <div class="col-md-10"><input type="text" name="link" value="<?=$item['link']?>" placeholder="Exam: http://zing.vn/" />
                	<span class="description">Exam: http://zing.vn/</span>
                    <br /><br />
                </div>
                              
                <div class="col-md-2"><label>Alphanumeric</label></div>
                <div class="col-md-10"><input type="text" name="stt" id="stt" value="<?=isset($item['stt'])?$item['stt']:1?>" placeholder="Số thứ tự" /></div>
                <div class="col-md-2"></div>
                <div class="col-md-10"><input type="checkbox" name="hienthi" class="icheck-blue" <?=(!isset($item['hienthi']) || $item['hienthi']==1)?'checked="checked"':''?> /> <span class="hienthi_text">Hiển thị</span></div>         
                
				<input type="hidden" name="id" id="id" value="<?=@$item['id']?>" />
                
                <div class="col-md-10 col-md-offset-2">                  
                  <button type="button" onclick="javascript:document.frm.submit()" class="btn btn-success"><i class="fa fa-check"></i>Save</button>
                  <button type="button" onclick="javascript:window.location='index.php?com=photo&act=partner<?=$chuoi_noi_curpage?>'" class="btn btn-info"><i class="fa fa-share"></i> Exit</button>
                </div>
                <div class="clearfix"></div>

              </form>

            </div>
          </div>
          <!-- Inline Form End -->
	</div>