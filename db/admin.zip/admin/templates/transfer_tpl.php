<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="REFRESH" content="4; url=<?=$page_transfer?>" />

<link href="media/images/favicon.ico" rel="shortcut icon" type="image/x-icon" />

<title>:: Website Administration ::</title>

<style>
	body{ margin:0px; padding:0px; background:url(media/images/LoadinBlue.gif) center 15px no-repeat; }
	#noidung{ font-size:15px; color:#333; padding:15px 30px 5px 30px; border:1px dashed #3AB0E4; text-align:center; min-width: 260px; max-width:400px; margin:90px auto 0px; }
	#noidung a{ color:#3AB0E4; text-decoration:none; transition:0.3s; -moz-transition:0.3s; -ms-transition:0.3s; -o-transition:0.3s; -webkit-transition:0.3s; }
	#noidung a:hover{ color:#06c; }
    hr{ border-top: 1px dashed #CCC;}
</style>

</head>

<body>    
    
    <div id='noidung'>	
    	<p><?=$showtext?></p>
        <hr size='1' />
        <p>( <a href="<?=$page_transfer?>">Click vào đây nếu bạn không muốn đợi lâu </a> )</p>
    </div>
    
</body>
</html>