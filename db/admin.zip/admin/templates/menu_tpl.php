<?php if(!defined('_kiemtraweb') || _kiemtraweb!=$check_website) daysangtranglogin(); ?>

	<!-- Logo Start -->
    <a href="index.php">
      <div class="logo-container">
        <h1>ADMIN</h1>
      </div>
    </a>

    <!-- Sidebar -->
    <div class="responsive-menu">
      <a href="#" onclick="return false;"><i class="fa fa-bars"></i></a>
    </div>

    <!-- Menu Start -->
<div class="tocify-nav-container">
    <ul class="menu tocify-box">
        <li class="parent purple <?=($com=='product')?'active':''?>">
            <a href="product" class="menu_click <?=($_SESSION['menu']['product']==2)?'':' close-child'?>">
              <span class="menu-icon"><i class="fa fa-align-justify"></i></span>
              <span class="menu-text">Production Management</span>
            </a>
            <ul class="child" <?=($_SESSION['menu']['product']==2)?' style="display: none;"':' style="display: block;"'?>>
                <li <?=($com=='product' && ($act=='man_cat' || $act=='add_cat' || $act=='edit_cat'))?' class="active"':''?>><i class="fa fa-check"></i>
                    <a href="index.php?com=product&act=man_cat">Category Level 1</a></li>
                <!--<li <?/*=($com=='product' && $act=='man_cat1')?' class="active"':''*/?>><i class="fa fa-check"></i>
                    <a href="index.php?com=product&act=man_cat1">Danh mục cấp 2</a></li>-->
                <!--<li <?/*=($com=='product' && $act=='man_cat2')?' class="active"':''*/?>><i class="fa fa-check"></i>
                    <a href="index.php?com=product&act=man_cat2">Danh mục Collection</a></li>-->
                <li <?=($com=='product' && $act=='man')?' class="active"':''?>><i class="fa fa-check"></i>
                    <a href="index.php?com=product&act=man">Product List</a></li>
           </ul>
        </li>

        <!--<li class="parent purple <?/*=($com=='tinnho' || $com=='tracking')?'active':''*/?>">
            <a href="tinnho" class="menu_click <?/*=($_SESSION['menu']['dichvu']==2 || $_SESSION['menu']['tracking']==2)?'':' close-child'*/?>">
                <span class="menu-icon"><i class="fa fa-clipboard"></i></span>
                <span class="menu-text">MODULE Dịch vụ</span>
            </a>
            <ul class="child" <?/*=($_SESSION['menu']['dichvu']==2 || $_SESSION['menu']['tracking']==2)?' style="display: none;"':' style="display: block;"'*/?>>
                <li <?/*=($act=='index' && $case =='dich-vu-cham-soc')?' class="active"':''*/?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=tinnho&act=index&case=dich-vu-cham-soc">Dịch vụ chăm sóc</a>
                </li>
            </ul>
        </li>-->


        <li class="parent purple <?=($com=='about' || $com=='tracking')?'active':''?>">
            <a href="about" class="menu_click <?=($_SESSION['menu']['dichvu']==2 || $_SESSION['menu']['tracking']==2)?'':' close-child'?>">
                <span class="menu-icon"><i class="fa fa-clipboard"></i></span>
                <span class="menu-text">MODULE Dịch vụ</span>
            </a>
            <ul class="child" <?=($_SESSION['menu']['dichvu']==2 || $_SESSION['menu']['tracking']==2)?' style="display: none;"':' style="display: block;"'?>>
                <li <?= ($com == 'about' && $act == 'index' && $case == 'project') ? ' class="active"' : '' ?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=about&act=index&case=project">Project</a>
                </li>
            </ul>
        </li>

        <!--<li class="parent purple <?/*=($com=='tinnho' || $com=='tracking')?'active':''*/?>">
            <a href="tinnho" class="menu_click <?/*=($_SESSION['menu']['media']==2 || $_SESSION['menu']['tracking']==2)?'':' close-child'*/?>">
                <span class="menu-icon"><i class="fa fa-clipboard"></i></span>
                <span class="menu-text">MODULE Media</span>
            </a>
            <ul class="child" <?/*=($_SESSION['menu']['media']==2 || $_SESSION['menu']['tracking']==2)?' style="display: none;"':' style="display: block;"'*/?>>
                <li <?/*=($act=='index' && $case =='tin-tuc')?' class="active"':''*/?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=tinnho&act=index&case=tin-tuc">Tin tức</a>
                </li>
                <li <?/*=($com=='images' && $case=='gallery')?' class="active"':''*/?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=images&act=index&case=gallery">Hình ảnh</a>
                </li>
            </ul>
        </li>-->

        <li class="parent purple <?=($com=='photo')?'active':''?>">
            <a href="photo" class="menu_click <?=($_SESSION['menu']['photo']==2)?'':' close-child'?>">
                <span class="menu-icon"><i class="fa fa-th"></i></span>
                <span class="menu-text">Other MODULE</span>
            </a>
            <ul class="child" <?=($_SESSION['menu']['photo']==2)?' style="display: none;"':' style="display: block;"'?>>
                <!--<li <?/*=($com=='photo' && $act=='capnhap_banner')?' class="active"':''*/?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=photo&act=capnhap_bg">Cập nhật Background</a></li>-->

                <li <?=($com=='photo' && $act=='capnhap_banner')?' class="active"':''?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=photo&act=capnhap_banner">Banner</a></li>
                <li <?=($com=='photo' && $act=='capnhap_bg')?' class="active"':''?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=photo&act=man">SlideShow Management</a></li>
                <li <?=($com=='photo' && $act=='partner')?' class="active"':''?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=photo&act=partner">Partner</a></li>
                <li <?=($com=='photo' && $act=='capnhat_logo')?' class="active"':''?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=photo&act=capnhat_logo">Logo</a></li>
                <!--<li <?/*=($com=='photo' && $act=='man_lkweb')?' class="active"':''*/?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=photo&act=man_lkweb">Liên kết</a></li>-->
                <!--<li <?/*=($com=='about' && $act=='vchat')?' class="active"':''*/?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=about&act=vchat">V-Chat</a></li>-->
            </ul>
        </li>
        <li class="parent purple <?=($com=='company')?'active':''?>">
            <a href="photo" class="menu_click <?=($_SESSION['menu']['company']==2)?'':' close-child'?>">
                <span class="menu-icon"><i class="fa fa-th"></i></span>
                <span class="menu-text">Company Management</span>
            </a>
            <ul class="child" <?=($_SESSION['menu']['company']==2)?' style="display: none;"':' style="display: block;"'?>>
                <li <?= ($com == 'about' && $act == 'index' && $case == 'about-us') ? ' class="active"' : '' ?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=about&act=index&case=about-us">About Us</a>
                </li>
                <li <?=($com=='company' && $act=='capnhap')?' class="active"':''?>>
                    <i class="fa fa-check"></i>
                    <a href="index.php?com=company&act=capnhap">Company Information</a></li>
                <!--<li <?/*=($com=='about' && $act=='capnhap6')?' class="active"':''*/?>><i class="fa fa-check"></i> <a href="index.php?com=about&act=capnhap6">Footer</a></li>-->
            </ul>
        </li>
    </ul>
</div>
<!-- Menu End -->