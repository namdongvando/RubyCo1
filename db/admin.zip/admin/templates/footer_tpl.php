<?php if(!defined('_kiemtraweb') || _kiemtraweb!=$check_website) daysangtranglogin(); ?>

<div class="col-sm-6">
	<h4>CÔNG TY TNHH THƯƠNG MẠI DỊCH VỤ VIETIT</h4>
    <p><b>Địa chỉ :</b> 38A Lê Văn Huân, F.15, Q.Tân Bình, Tp. Hồ Chí Minh.</p>
</div>
<div class="col-sm-3">   
    <p><b>Điện thoại :</b> <span class="dienthoai_footer">086.2701250</span></p>
	<p><b>Email :</b> <span class="mail_footer">info@vietit.vn</span></p>  
	    <p><b>Kỹ Thuật  :</b> <a href="https://www.facebook.com/NguyenAnhQuocCs" target="_blank" title="Dev. Đinh Công Minh" style="font-size:11px">Dev.Nguyễn Anh Quốc</a></p>
</div>
<div class="col-sm-3">
	<p><b>Phiên bản hiện tại :</b> <span class="dienthoai_footer">6.14</span></p>    
    <p><b>Website :</b> <a href="http://vietit.vn/" target="_blank" title="CÔNG TY TNHH THƯƠNG MẠI DỊCH VỤ VIETIT">www.vietit.vn</a></p>  
</div>
<div class="clear"></div>


  